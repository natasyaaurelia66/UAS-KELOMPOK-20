import 'package:flutter/material.dart';

TextStyle mainStyle = const TextStyle(
  fontWeight: FontWeight.bold,
  fontSize: 20,
  color: Colors.pinkAccent,
);
