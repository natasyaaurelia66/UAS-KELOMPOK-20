package com.example.flutter_resep_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
